package com.micro.multiplex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiplexApplication {

	public static void main(String[] args) {
		SpringApplication.run(MultiplexApplication.class, args);
	}

}
