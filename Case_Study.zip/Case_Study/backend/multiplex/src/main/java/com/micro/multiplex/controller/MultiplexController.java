package com.micro.multiplex.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

import com.micro.multiplex.document.MultiplexDetail;
import com.micro.multiplex.dto.MultiplexDetailDto;
import com.micro.multiplex.dto.RegisterMultiplexDto;
import com.micro.multiplex.dto.UpdateDetailDto;
import com.micro.multiplex.service.MultiplexService;


@RestController
@RequestMapping("/api/multiplex")
public class MultiplexController {
	
	private MultiplexService multiplexService;
	
	@Autowired
	public MultiplexController(MultiplexService multiplexService) {
		this.multiplexService = multiplexService;
	}
	@PostMapping("/register")
	public ResponseEntity<MultiplexDetailDto> register(@RequestBody RegisterMultiplexDto registerDto) {
		MultiplexDetailDto multiplexDetailDto = this.multiplexService.register(registerDto);
		ResponseEntity<MultiplexDetailDto> response = 
				new ResponseEntity<MultiplexDetailDto>(multiplexDetailDto,HttpStatus.OK);
		return response;
	}
	
	@GetMapping("/getAllMultiplexes")
	public ResponseEntity<List<MultiplexDetail>> getAllMultiplexes() {
		List<MultiplexDetail> getMultiplexes=this.multiplexService.getAllMultiplexes();
		ResponseEntity<List<MultiplexDetail>> response = 
				new ResponseEntity<List<MultiplexDetail>>(getMultiplexes,HttpStatus.OK);
		return response;
	}
	@GetMapping("/get/{multiplexId}")
	public ResponseEntity<MultiplexDetailDto> getMultiplexDetail(@PathVariable("multiplexId")String multiplexId) {
		MultiplexDetailDto multiplexDetailDto =  this.multiplexService.getMultiplexDetail(multiplexId);
		// manage user not found exception
		ResponseEntity<MultiplexDetailDto> response = 
				new ResponseEntity<MultiplexDetailDto>(multiplexDetailDto,HttpStatus.OK);
		return response;
		
	}
	@DeleteMapping("/delete/{multiplexId}")
	public void deleteMultiplex(@PathVariable("multiplexId")String multiplexId) {
	
	this.multiplexService.deleteMultiplex(multiplexId);

	}
	
	@PutMapping("/update/{multiplexId}")
	public ResponseEntity<MultiplexDetailDto> updateMultiplexDetail(@PathVariable("multiplexId")String multiplexId,@RequestBody UpdateDetailDto updateDto) {
		MultiplexDetailDto multiplexDetailDto =this.multiplexService.updateMultiplexDetail(multiplexId,updateDto);
		ResponseEntity<MultiplexDetailDto> response = 
				new ResponseEntity<MultiplexDetailDto>(multiplexDetailDto,HttpStatus.OK);
		return response;
	}
}
