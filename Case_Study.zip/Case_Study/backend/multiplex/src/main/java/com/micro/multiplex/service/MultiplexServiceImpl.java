package com.micro.multiplex.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.micro.multiplex.dao.MultiplexRepository;
import com.micro.multiplex.document.MultiplexDetail;
import com.micro.multiplex.dto.MultiplexDetailDto;
import com.micro.multiplex.dto.RegisterMultiplexDto;
import com.micro.multiplex.dto.UpdateDetailDto;
@Service
public class MultiplexServiceImpl implements MultiplexService {
	private MultiplexRepository repository;
	
	public MultiplexServiceImpl(MultiplexRepository repository) {
		this.repository = repository;
	}
	@Override
	public MultiplexDetailDto register(RegisterMultiplexDto registerDto) {
		//covert dto->Document
		MultiplexDetail multiplexDetail = new MultiplexDetail(null, 
				   registerDto.getMultiplexName(),
				   registerDto.getAddress(), 
				   registerDto.getNumberOfScreens(), 
				   registerDto.getScreenList());
        multiplexDetail = this.repository.save(multiplexDetail);
        // convert Document->Dto
        MultiplexDetailDto  multiplexDetailDto = new MultiplexDetailDto (multiplexDetail.getMultiplexId(), 
		multiplexDetail.getMultiplexName(), 
		multiplexDetail.getAddress(), 
		multiplexDetail.getNumberOfScreens(),
		multiplexDetail.getScreenLists());
        return multiplexDetailDto;
	}
	@Override
	public List<MultiplexDetail> getAllMultiplexes() {
		List<MultiplexDetail> getAllMultiplexes=(List<MultiplexDetail>) this.repository.findAll();
		return getAllMultiplexes;
	}
	@Override
	public MultiplexDetailDto getMultiplexDetail(String multiplexId) {
		MultiplexDetail multiplexDetail =  this.repository.findById(multiplexId).orElse(null);
		if(multiplexDetail != null) {
			MultiplexDetailDto multiplexDetailDto= new MultiplexDetailDto(multiplexDetail.getMultiplexId(), 
					multiplexDetail.getMultiplexName(), 
					multiplexDetail.getAddress(), 
					multiplexDetail.getNumberOfScreens(),
					multiplexDetail.getScreenLists());
			return multiplexDetailDto;
		}
		return null;
	}
	@Override
	public void deleteMultiplex(String multiplexId) {
		MultiplexDetail multiplexDetail =  this.repository.findById(multiplexId).orElse(null);
		if(multiplexDetail != null) {
			repository.deleteById(multiplexId);	
		}
	}
	@Override
	public MultiplexDetailDto updateMultiplexDetail(String multiplexId, UpdateDetailDto updateDto) {
		MultiplexDetail multiplexDetail =  this.repository.findById(multiplexId).orElse(null);
		if(multiplexDetail != null) {
			multiplexDetail.setMultiplexId(multiplexId);
			multiplexDetail.setMultiplexName(updateDto.getMultiplexName());
			multiplexDetail.setAddress(updateDto.getAddress());
			multiplexDetail.setNumberOfScreens(updateDto.getNumberOfScreens());
			multiplexDetail.setScreenLists(updateDto.getScreenList());
			
			multiplexDetail = this.repository.save(multiplexDetail);
			  MultiplexDetailDto  multiplexDetailDto = new MultiplexDetailDto (multiplexDetail.getMultiplexId(), 
						multiplexDetail.getMultiplexName(), 
						multiplexDetail.getAddress(), 
						multiplexDetail.getNumberOfScreens(),
						multiplexDetail.getScreenLists());
				        return multiplexDetailDto;
		}
		return null;
	}
	
	
	
	
}

