package com.micro.multiplex.dao;

import org.springframework.data.repository.CrudRepository;

import com.micro.multiplex.document.MultiplexDetail;

public interface MultiplexRepository extends CrudRepository<MultiplexDetail, String> {

}
