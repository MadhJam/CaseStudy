package com.micro.movie.dao;

import org.springframework.data.repository.CrudRepository;

import com.micro.movie.document.MovieDetail;



public interface MovieRepository extends CrudRepository<MovieDetail, String> {

}
