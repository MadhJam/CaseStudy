package com.micro.movie.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.micro.movie.dao.MovieRepository;
import com.micro.movie.document.MovieDetail;
import com.micro.movie.dto.AddMovieDto;
import com.micro.movie.dto.MovieDetailDto;
import com.micro.movie.dto.UpdateMovieDto;





@Service
public class MovieServiceImpl implements MovieService {
	private MovieRepository movieRepository;
	
	public MovieServiceImpl(MovieRepository movieRepository) {
		this.movieRepository = movieRepository;
	}
	@Override
	public MovieDetailDto addMovie(AddMovieDto addMovieDto) {
		MovieDetail movieDetail = new MovieDetail(null, 
				   addMovieDto.getMovieName(),
				   addMovieDto.getCategory(), 
				   addMovieDto.getProducer(),
				   addMovieDto.getDirector());
				   //addMovieDto.getReleaseDate()
		movieDetail = this.movieRepository.save(movieDetail);
     // convert Document->Dto
     MovieDetailDto  movieDetailDto = new MovieDetailDto (movieDetail.getMovieId(), 
		movieDetail.getMovieName(), 
		movieDetail.getCategory(), 
		movieDetail.getProducer(),
		movieDetail.getDirector());
		//movieDetail.getReleaseDate()
     return movieDetailDto;
	}

	@Override
	public List<MovieDetail> getAllMovies() {
		List<MovieDetail> getAllMovies=(List<MovieDetail>) this.movieRepository.findAll();
		return getAllMovies;
	}

	@Override
	public MovieDetailDto getMovieDetail(String movieId) {
		MovieDetail movieDetail =  this.movieRepository.findById(movieId).orElse(null);
		if(movieDetail != null) {
			MovieDetailDto movieDetailDto= new MovieDetailDto(movieDetail.getMovieId(), 
					movieDetail.getMovieName(), 
					movieDetail.getCategory(), 
					movieDetail.getProducer(),
					movieDetail.getDirector());
					//movieDetail.getReleaseDate()
			return movieDetailDto;
		}
		return null;
	}

	@Override
	public void deleteMovie(String movieId) {
		MovieDetail movieDetail =  this.movieRepository.findById(movieId).orElse(null);
		if(movieDetail != null) {
			movieRepository.deleteById(movieId);
			}
	}

	@Override
	public MovieDetailDto updateMovieDetail(String movieId, UpdateMovieDto updateMovieDto) {
		MovieDetail movieDetail =  this.movieRepository.findById(movieId).orElse(null);
		if(movieDetail != null) {
			movieDetail.setMovieId(movieId);
			movieDetail.setMovieName(updateMovieDto.getMovieName());
			movieDetail.setCategory(updateMovieDto.getCategory());
			movieDetail.setProducer(updateMovieDto.getProducer());
			movieDetail.setDirector(updateMovieDto.getDirector());
			//movieDetail.setReleaseDate(updateMovieDto.getReleaseDate());
			
			movieDetail = this.movieRepository.save(movieDetail);
			MovieDetailDto  movieDetailDto = new MovieDetailDto (movieDetail.getMovieId(), 
					  movieDetail.getMovieName(),
					  movieDetail.getCategory(),
					  movieDetail.getProducer(),
					  movieDetail.getDirector());
			          //movieDetail.getReleaseDate()
				      return movieDetailDto;
		}
		return null;
	}

}
