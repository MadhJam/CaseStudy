package com.micro.user.exception;

public class BoundaryException extends RuntimeException{
	
	public BoundaryException(String message) {
		super(message);
	}

}