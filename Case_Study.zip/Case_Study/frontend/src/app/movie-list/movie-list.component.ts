import { Component, OnInit } from '@angular/core';
import { Movie } from '../model/movie.model';
import { Observable } from 'rxjs';
import { MovieService } from '../service/data/movie.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent implements OnInit {
 
 /* movies: Observable<Movie[]>;*/
 movies: Movie[];

  constructor(private movieService: MovieService,
    private router: Router) {
        this.movies= [
          new Movie(1,"First", "thriller","a","a",new Date(Date.now())),
          new Movie(2,"Second", "Horror","b","b",new Date(Date.now()))
        ]
      }
    
    

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
   /* this.movies = this.movieService.getMovieList();*/
   this.movieService.getMovieList().subscribe(
    // call back method
    (response:any) => this.movies = response
  )
  }

  deleteMovie(id: number) {
    /*this.movieService.deleteMovie(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));*/
  }

  movieDetails(id: number){
    this.router.navigate(['details', id]);
  }

}
