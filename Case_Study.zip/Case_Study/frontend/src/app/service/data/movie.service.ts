import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  private baseUrl = 'http://localhost:6060/api/movie';

  constructor(private http: HttpClient) { }

  getMovie(id: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${id}`);
  }

  getMovieList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}
