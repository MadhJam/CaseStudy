import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthenticationService } from './authentication.service';


@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate{

  constructor(private auth : AuthenticationService,private router : Router ) { 

  }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot){
      // guard logic
      // if user is logged in
      if(this.auth.isUserLoggedIn()){
        // route : additional info about request(component) being generated
        // route.url
        return true;
      }else{
        // navigate to login component
        this.router.navigate(['/login']);
        return false;
      }

  }
  
}
