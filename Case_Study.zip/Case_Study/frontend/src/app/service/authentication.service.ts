import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  authenticate(loginid : string, password : string):boolean{
    // hard coded validation
    if(loginid === "First" && password === "abc"){
      // need to maintain status : session storage
      sessionStorage.setItem("user", loginid);
      return true;
    }else{
        return false;
    }
  }

  isUserLoggedIn(): boolean{
    // if 'user' key is present
    let user = sessionStorage.getItem('user');
    if(user == null)
      return false;
    else
      return true;  
  }

  //  can have method to return type of user

  logout(){
    sessionStorage.removeItem('user');
  }





  constructor() { }
}
