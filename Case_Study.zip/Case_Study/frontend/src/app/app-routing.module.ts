import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { MovieListComponent } from './movie-list/movie-list.component';
import { MovieDetailsComponent } from './movie-list/movie-details/movie-details.component';

const routes: Routes = [
    {path:"", redirectTo : "login", pathMatch : "full"},
    {path:"login", component : LoginComponent},
    {path:"register", component : RegisterComponent},
    {path:"movie-list", component : MovieListComponent},/*children :[*/
    {path :"details", component : MovieDetailsComponent}
      /*]}*/
];
@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }
  