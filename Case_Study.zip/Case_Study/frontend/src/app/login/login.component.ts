import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginName:string;
  password:string;

  userFormGroup : FormGroup;
  constructor(formBuilder : FormBuilder,private router: Router) { 
    this.userFormGroup = formBuilder.group({
      "user_name" : new FormControl('',Validators.required),
      "password" : new FormControl('',Validators.required)
    });
  }
  loginUser(){
    this.loginName = this.userFormGroup.controls['user_name'].value;
    this.password = this.userFormGroup.controls['password'].value;
    this.router.navigate(['/movie-list']);
  }

  ngOnInit(): void {
  }

}
