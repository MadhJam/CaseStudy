import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  firstName:string;
  lastName:string;
  userName:string;
  password:string;

  registerForm: FormGroup;
  constructor(formBuilder : FormBuilder,private router: Router) { 
    this.registerForm = formBuilder.group({
      "firstName" : new FormControl('',Validators.required),
      "lastName" : new FormControl('',Validators.required),
      "userName" : new FormControl('',Validators.required),
      "password" : new FormControl('',Validators.required)
    });
  }
    registerUser(){
    this.firstName = this.registerForm.controls['firstName'].value;
    this.lastName = this.registerForm.controls['lastName'].value;
    this.userName = this.registerForm.controls['userName'].value;
    this.password = this.registerForm.controls['password'].value;
    this.router.navigate(['/movie-list']);
  }

  ngOnInit(): void {
  }

}

